import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.sahil.grid_adapter.R
import com.sahil.grid_adapter.databinding.ScreenOneBinding

class ScreenOne : Fragment(R.layout.screen_one) {

    private lateinit var binding: ScreenOneBinding
    private val simpleAdapter = SimpleAdapter()

    private val PERMISSION_REQUEST_CODE = 123
    private val PICK_IMAGE_REQUEST_CODE = 456
    private var selectedImageUri: Uri? = null

    // Register the ActivityResultLauncher for image selection
    private val getContent = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { imageUri ->
            selectedImageUri = imageUri
            simpleAdapter.addImage(imageUri.toString())
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding = ScreenOneBinding.bind(view)

        binding.rv.adapter = simpleAdapter
        binding.btn.setOnClickListener {
            if (isReadStoragePermissionGranted()) {
                openGallery()
            } else {
                requestReadStoragePermission()
            }
        }
    }

    private fun isReadStoragePermissionGranted(): Boolean {
        return ContextCompat.checkSelfPermission(
            requireContext(),
            Manifest.permission.READ_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestReadStoragePermission() {
        ActivityCompat.requestPermissions(
            requireActivity(),
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
            PERMISSION_REQUEST_CODE
        )
    }

    private fun openGallery() {
        getContent.launch("image/*")
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openGallery()
            }
        }
    }
}
