import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sahil.grid_adapter.databinding.ItemBinding

class SimpleAdapter : RecyclerView.Adapter<SimpleAdapter.ViewHolder>() {

    private val itemList = mutableListOf<String>()

    inner class ViewHolder(var binding: ItemBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(imageUri: String) {
            Glide.with(binding.iv.context)
                .load(imageUri)
                .centerCrop()
                .into(binding.iv)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder =
        ViewHolder(ItemBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val imageUri = itemList[position]
        holder.bind(imageUri)
    }

    override fun getItemCount() = itemList.size

    fun addImage(imageUri: String) {
        itemList.add(imageUri)
        notifyDataSetChanged()
    }
}
