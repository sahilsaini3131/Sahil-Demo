package com.sahil.screen1

import androidx.lifecycle.ViewModel
import androidx.recyclerview.widget.RecyclerView.ViewHolder

class ScreenOneVM:ViewModel() {

}